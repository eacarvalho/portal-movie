$(function () {

  $('#form-validation').validator();

});